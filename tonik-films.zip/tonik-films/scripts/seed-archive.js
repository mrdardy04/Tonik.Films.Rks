// scripts/seed-archive.js
// Run: npm run seed:archive
const fs = require('fs');
const axios = require('axios');

async function fetchFromArchive(query, rows = 200) {
  const url = 'https://archive.org/advancedsearch.php';
  const params = {
    q: query,
    fl: ['identifier','title','year','description','rights','mediatype','format'],
    rows,
    page: 1,
    output: 'json'
  };
  const resp = await axios.get(url, { params, timeout: 30000 });
  return resp.data.response.docs || [];
}

async function getItemFiles(identifier) {
  const url = `https://archive.org/metadata/${identifier}`;
  const resp = await axios.get(url, { timeout: 30000 });
  const files = resp.data.files || [];
  const candidates = files.filter(f => {
    const fmt = (f.format || '').toLowerCase();
    return fmt.includes('mpeg4') || fmt.includes('mp4') || fmt.includes('h.264') || (f.name && f.name.endsWith('.mp4'));
  });
  return candidates.map(f => ({
    name: f.name,
    format: f.format,
    size: f.size || null,
    url: `https://archive.org/download/${identifier}/${f.name}`
  }));
}

(async () => {
  try {
    console.log('Kerkim në Internet Archive për tituj publike...');
    const query = 'mediatype:(movies) AND (rights:(public domain) OR rights:("Public Domain"))';
    const docs = await fetchFromArchive(query, 300);
    console.log(`Gjetur ${docs.length} dokumente; po përpunojmë...`);

    const results = [];
    for (let d of docs) {
      try {
        const identifier = d.identifier;
        if (!identifier) continue;
        const files = await getItemFiles(identifier);
        if (!files || files.length === 0) continue;
        results.push({
          id: identifier,
          title: d.title || identifier,
          year: d.year || null,
          description: d.description || '',
          rights: d.rights || '',
          mediatype: d.mediatype || '',
          files
        });
        console.log(`✔ ${identifier} -> ${files.length} file(s)`);
        if (results.length >= 100) break;
      } catch (err) {
        console.warn('Gabim me dokumentin', d && d.identifier, err && err.message);
      }
    }

    const outPath = './data/seed-films.json';
    fs.mkdirSync('./data', { recursive: true });
    fs.writeFileSync(outPath, JSON.stringify(results, null, 2), 'utf-8');
    console.log(`Saved ${results.length} items to ${outPath}`);
  } catch (err) {
    console.error('Gabim gjeneral:', err && err.message);
    process.exit(1);
  }
})();
