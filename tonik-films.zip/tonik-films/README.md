# Tonik Films — Demo Next.js App

IMPORTANT: This project is for **legal** streaming only. Only add films you own or that are clearly public-domain / Creative Commons licensed for redistribution. Verify rights before hosting.

## What is included
- Next.js scaffold (pages + API route)
- `scripts/seed-archive.js` — Node script that queries Internet Archive advanced search & metadata API to build `data/seed-films.json` (you must run this locally; the script requires internet access).
- Minimal UI and video player that uses mp4 URLs in `data/seed-films.json`.

## Quick start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Seed the catalog (requires internet access):
   ```bash
   npm run seed:archive
   ```
   This will create `data/seed-films.json` with up to ~100 public-domain items (depending on search results).
3. Run dev server:
   ```bash
   npm run dev
   ```
4. Open http://localhost:3000

## Deploying to Vercel
1. Push this repo to GitHub.
2. Create an account at https://vercel.com and import the repo.
3. Vercel detects Next.js and deploys automatically. After deploy you'll get a public URL.

## Legal notes
- The seed script searches for items tagged as Public Domain on Internet Archive; metadata may be incorrect for some items — you must verify rights before public distribution.
- For production use, host videos on S3 + CDN and use signed URLs for heavy traffic.

