// components/Player.js
import React from 'react';

export default function Player({ item }) {
  if (!item) return <div style={{ padding: 20, background: '#111', color: '#fff' }}>Zgjidh një film për të parë.</div>;
  const files = (item.files || []).slice().sort((a,b)=> (b.size||0)-(a.size||0));
  const mp4 = files.find(f=>f.url && f.url.endsWith('.mp4')) || files[0];
  if (!mp4) return <div style={{ padding: 20 }}>No playable file found.</div>;

  return (
    <div>
      <h2 style={{ marginBottom: 6 }}>{item.title} {item.year ? `(${item.year})` : ''}</h2>
      <p style={{ color: '#999', marginTop: 0 }}>{item.description || ''}</p>
      <video controls width="640" poster="/placeholder.jpg" style={{ background:'#000', borderRadius: 8, marginTop: 8 }}>
        <source src={mp4.url} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <p style={{ fontSize: 12, color: '#666' }}>Source: {mp4.url}</p>
    </div>
  );
}
