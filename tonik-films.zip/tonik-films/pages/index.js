// pages/index.js
import { useEffect, useState } from 'react';
import Player from '../components/Player';

export default function Home() {
  const [items, setItems] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    fetch('/api/films').then(r => r.json()).then(d => setItems(d.items || []));
  }, []);

  return (
    <div style={{ padding: 20, fontFamily: 'Inter, system-ui, sans-serif', color: '#fff', background: '#0b0b0b', minHeight: '100vh' }}>
      <h1>Tonik Films — Demo Catalog</h1>
      <p style={{ color: '#999' }}>Shfaq vetëm përmbajtje që zotëroni ose që është public domain.</p>

      <div style={{ display: 'flex', gap: 20, marginTop: 20 }}>
        <div style={{ flex: 1 }}>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {items.map(item => (
              <li key={item.id} style={{ marginBottom: 12 }}>
                <button onClick={() => setSelected(item)} style={{ width: '100%', textAlign: 'left' }}>
                  <strong>{item.title}</strong> <span style={{ color: '#888' }}>({item.year || 'n/a'})</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div style={{ width: 680 }}>
          <Player item={selected} />
        </div>
      </div>
    </div>
  );
}
