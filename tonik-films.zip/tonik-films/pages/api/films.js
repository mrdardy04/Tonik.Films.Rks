// pages/api/films.js
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  const file = path.join(process.cwd(), 'data', 'seed-films.json');
  if (!fs.existsSync(file)) return res.status(200).json({ items: [] });
  const raw = fs.readFileSync(file, 'utf8');
  const items = JSON.parse(raw);
  res.status(200).json({ items });
}
